// WOW active
new WOW().init();