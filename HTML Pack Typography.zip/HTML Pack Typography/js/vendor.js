$(document).ready(function(){
		
		//sticky
		$(".js--services-section").waypoint(function(direction){
		
				if(direction=="down"){
						$("nav").addClass("sticky");
				} else {
						$("nav").removeClass("sticky");
				}
		
		})
		
		//header
		  $(function() {
        $('.animate-type').animatedHeadline({
            animationType: 'type'
        });
    })
		
		//portfoilo
		var mixer= mixitup('.container');
})